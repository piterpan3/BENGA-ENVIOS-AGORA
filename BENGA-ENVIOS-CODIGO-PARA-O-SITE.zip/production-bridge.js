/* BENGA ENVIOS — compatibility bridge for the static front-end.
   The current HTML stores demo state in localStorage. This bridge intentionally
   stays dependency-free so the page also works on static hosting while the
   production API can be connected later without changing index.html. */
(function () {
  'use strict';
  window.BENGA_ENV = window.BENGA_ENV || { mode: 'static-preview' };
})();
