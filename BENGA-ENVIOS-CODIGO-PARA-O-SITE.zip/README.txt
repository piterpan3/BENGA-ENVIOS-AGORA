BENGA ENVIOS — Código do site
=============================

Arquivos:
- index.html              -> página completa do site
- production-bridge.js    -> ponte de compatibilidade para o HTML
- vercel.json             -> configuração mínima para hospedagem estática

O index.html já contém o CSS, imagens de fundo e os scripts do preview.
Basta colocar os três arquivos juntos no alojamento estático.

IMPORTANTE:
Esta versão é o front-end/preview. O login, cadastro, encomendas e estados
usam a lógica presente no HTML/localStorage. Para uso real com clientes,
credenciais, e-mail de verificação e base de dados devem ficar no servidor.
